$(function(){
    
    let li1=$("<li id='fourthElementsli1_Stars'><img src='../img/LeaseImg/LeaseImg1.png'><div class='fourthElementsDiv_Stars'><p><a href='#'><strong>剑桥探索公园，400-500号楼</strong></a></p><h2>马萨诸塞州剑桥市</h2><h3>270,000 SF</h3><a href='#'><div><p>查看详情</p></div></a></div></li>")
    $('.fourthElements_Stars ul').append(li1)
    
    let type=["","肯德里克街117号","1560 TRAPELO ROAD","第二大道75号","泰勒技术中心","德比街99-101号","第二个李约瑟所","250第一大道","教堂街59-63号","1285 BEACON STREET"]
    let city=["","李约瑟，马萨诸塞州","马萨诸塞州沃尔瑟姆","李约瑟，马萨诸塞州","马萨诸塞州利特尔顿","马萨诸塞州，Hingham","李约瑟，马萨诸塞州","李约瑟，马萨诸塞州","马萨诸塞州剑桥市","马萨诸塞州布鲁克莱恩"]
    let price=["","213,000 SF","61,000 SF","111,928 SF","98,262 SF","62,793 SF","28,269 SF","73,167 SF","10,822 SF","21,360 SF"]

    for(let i=2;i<10;i++){        
        let li=$("<li class='diSiHanliZzj' id='fourthElementsli"+i+"_Stars'><img src='../img/LeaseImg/LeaseImg"+i+".png'><div class='fourthElementsDiv_Stars'><p><a href='#'><strong>"+type[i]+"</strong></a></p><h2>"+city[i]+"</h2><h3>"+price[i]+"</h3><a href='#'><div><p>查看详情</p></div></a></div></li>")    
        $('.fourthElements_Stars ul').append(li)
    }
                
})