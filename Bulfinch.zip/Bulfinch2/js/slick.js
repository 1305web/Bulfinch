var oBox = document.getElementsByClassName("sec_fivesmall_lx")[0];
var aBoxcontent = document.getElementsByClassName("sec_fivesmallbox_lx");

var w = 0

window.onload = function(){
    let boxwidth = document.documentElement.clientWidth;
    for(var i = 0 ; i < aBoxcontent.length ;i++){
        aBoxcontent[i].style.width = (boxwidth)+"px";       
    }
    oBox.style.width = ((boxwidth)*3)+"px";
    w = boxwidth;   
    show(w)
}

window.onresize=function(){
    let boxwidth = document.documentElement.clientWidth;
    oBox.style.left = "0px"
    for(var i = 0 ; i < aBoxcontent.length ;i++){
        aBoxcontent[i].style.width = (boxwidth)+"px";       
    }
    oBox.style.width = ((boxwidth)*3)+"px";
    w = boxwidth;   
    show(w)
}

function show(w){
        let b = w;
        let a = 0;
        let c = 0;
        oBox.addEventListener("mousedown",function(ev){
            ev = ev || window.event;
            a++
   
            
            let mousedownAddrs = ev.clientX
            
            document.onmousemove = (ev)=>{
                oBox.style.transition = "0.5s";
                console.log(a);
                let moveAddrs = ev.clientX - mousedownAddrs;
                if(moveAddrs < 0){
                   
                    if(a > 2 ){
                        a = 0;
                        oBox.style.left = 0+"px";

                    }else{
                        oBox.style.left = (-w*a)+"px";
                    }
                }
                
                if(moveAddrs > 0){

                    if(a == 0){
                        a--
                        oBox.style.left = (-w*2)+"px";
                        a = 2;
                    }

                    if(a == 2){
                        a = 0;
                        oBox.style.left = 0+"px"
                    }

                    if(a == 3){
                        a = 1;
                        oBox.style.left = -b+"px"
                    }                             
                } 
            }

            document.onmouseup = function(){        
                document.onmousedown = null;
                document.onmousemove = null;
            }
        })

}





