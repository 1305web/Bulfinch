$(function(){
    var dropDown_Stars=document.getElementById('dropDown_Stars');
    var dropDownMenu_Stars=document.getElementById('dropDownMenu_Stars');
    var secondHidden_Stars=document.getElementById('secondHidden_Stars');
    var dropDown1_Stars=document.getElementById('dropDown1_Stars');
    var dropDown2_Stars=document.getElementById('dropDown2_Stars');
    var dropDown3_Stars=document.getElementById('dropDown3_Stars');
    var tru=true
    setInterval(function(){
        var client=document.documentElement.clientWidth
        if(client>930){
            dropDownMenu_Stars.style.display='none'
            secondHidden_Stars.style.display='block';
            dropDown1_Stars.style.transform='rotate(0deg) translate(0px,0px)';      
            dropDown2_Stars.style.transform='translate(0px,0)';
            dropDown2_Stars.style.opacity=1;
            dropDown3_Stars.style.transform='rotate(0deg) translate(0px,0px)';
        }
    },1)
    dropDown_Stars.onclick=function(){
        if(tru){
            dropDownMenu_Stars.style.display='block';
            secondHidden_Stars.style.display='none';
            dropDown1_Stars.style.transform='rotate(45deg) translate(0px,5px)';      
            dropDown2_Stars.style.transform='translate(-40px,0)';
            dropDown2_Stars.style.opacity=0;
            dropDown3_Stars.style.transform='rotate(-45deg) translate(10px,-15px)';
        }else{
            dropDownMenu_Stars.style.display='none'
            secondHidden_Stars.style.display='block';
            dropDown1_Stars.style.transform='rotate(0deg) translate(0px,0px)';      
            dropDown2_Stars.style.transform='translate(0px,0)';
            dropDown2_Stars.style.opacity=1;
            dropDown3_Stars.style.transform='rotate(0deg) translate(0px,0px)';
        }
        tru=!tru
    }
})

