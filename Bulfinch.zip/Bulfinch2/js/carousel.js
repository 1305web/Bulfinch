window.onload = ()=>{
    let carouselPic = document.querySelector('.main_pic_carl');
    let oUl = document.querySelector('.main_pic_ul_carl');
    let aLi = oUl.querySelectorAll('li');
    let leftArrows = document.querySelector('.left_arrows_carl');
    let rightArrows = document.querySelector('.right_arrows_carl');
    let spanGroup = document.querySelector('.main_spot_carl');
    let aSpan = spanGroup.querySelectorAll('span');
    // 左箭头点击事件
    leftArrows.onclick = ()=>{
        if(aLi[0].className === 'pic_active_carl'){
            oUl.style.transition = '0s';
            oUl.style.transform = 'translateX(-80%)';
            aLi[4].className = 'pic_active_carl';
            aLi[0].className = '';
        }
        setTimeout(()=>{
            [...aLi].forEach((item,i)=>{
                if(item.className === 'pic_active_carl'){
                    oUl.style.transition = '.3s';
                    oUl.style.transform = `translateX(${(i-1)*(-20)}%)`;
                    aLi[i-1].className = 'pic_active_carl';
                    item.className = '';
                    aSpan[i%4].className = '';
                    aSpan[i-1].className = 'active_carl';
                }
            })
        },0)
    }
    // 右箭头点击事件
    rightArrows.onclick = ()=>{
        if(aLi[4].className === 'pic_active_carl'){
            oUl.style.transition = '0s';
            oUl.style.transform = 'translateX(0)';
            aLi[0].className = 'pic_active_carl';
            aLi[4].className = '';
        }
        setTimeout(()=>{
            let count = [...aLi].map((item,i)=>{
                if(item.className === 'pic_active_carl'){
                    oUl.style.transition = '.2s';
                    oUl.style.transform = `translateX(${(i+1)*(-20)}%)`;
                    item.className = '';
                    aSpan[i].className = '';
                    aSpan[(i+1)%4].className = 'active_carl';
                    return i;
                }
            })
            let icount = count.filter(item=>item != undefined);
            aLi[(icount[0]+1)%5].className = 'pic_active_carl';
        },0)
    }
    // 轮播下标点点击事件
    [...aSpan].forEach((item,i)=>{
        item.onclick=function(){
            [...aSpan].forEach((item1,i)=>{
                item1.className = '';
            })
            this.className = 'active_carl';
            oUl.style.transform = `translateX(${i*(-20)}%)`;
        }
    })

    let picWidth = carouselPic.clientWidth;
    carouselPic.onmousedown = function(ev){
        let siteX = ev.clientX;
        carouselPic.onmousemove = function(ev){
            let currentX = ev.clientX;
            let minusX = siteX - currentX;
            let percent = minusX/picWidth*0.2;
            console.log(percent);
            let num = getComputedStyle(oUl).transform.match(/\d{1,2}/g);
            console.log(getComputedStyle(oUl).transform);
            console.log(num);
            oUl.style.transform = `translateX(${(-num)+percent}%)`;
            document.onmouseup=function(ev){
                carouselPic.onmousemove = null;
                if(percent > 0.04){
                    oUl.style.transform = `translateX(${(-num)+20}%)`;
                }else if(percent < -0.04){
                    oUl.style.transform = `translateX(${(-num)-20}%)`;
                }else{
                    oUl.style.transform = `translateX(${-num}%)`;
                }
            }
        }

    }

}

