class NewsCarl{
    constructor(obj){
        this.obj = obj;
        this.oMain = document.querySelector('main');
        this.oPage = document.querySelector('.pagination_carl');
        // 创建DOM元素
        this.section = document.createElement('section');
        this.oDiv1 = document.createElement('div');
        this.oImg = document.createElement('img');
        this.oDiv2 = document.createElement('div');
        this.oA1 = document.createElement('a');
        this.oP1 = document.createElement('p');
        this.oDiv3 = document.createElement('div');
        this.oH2 = document.createElement('h2');
        this.oDiv4 = document.createElement('div');
        this.oDiv5 = document.createElement('div');
        this.oA2 = document.createElement('a');
        // 设置DOM元素的属性和内容
        this.section.className='list01_carl';
        this.oImg.src=this.obj.img;
        this.oDiv2.className='list01_con_carl';
        this.oA1.href=`news.html`;
        this.oP1.innerText=this.obj.content;
        this.oDiv3.className='stage_carl';
        this.oH2.innerText=this.obj.title;
        this.oDiv4.className='cube_carl';
        this.oDiv5.className='btn1_carl';
        this.oA2.href=`news.html`;
        this.oA2.innerText='read the story';
        // 将DOM元素插入到相应的元素中形成结构
        this.section.appendChild(this.oDiv1);
        this.oDiv1.appendChild(this.oImg);
        this.section.appendChild(this.oDiv2);
        this.oDiv2.appendChild(this.oA1);
        this.oA1.appendChild(this.oH2);
        this.oDiv2.appendChild(this.oP1);
        this.oDiv2.appendChild(this.oDiv3);
        this.oDiv3.appendChild(this.oDiv4);
        this.oDiv4.appendChild(this.oDiv5);
        this.oDiv5.appendChild(this.oA2);
        // 循环生成div
        for(let i=0;i<5;i++){
            this.oDiv6 = document.createElement('div');
            this.oDiv4.appendChild(this.oDiv6);
        }
        // 将组件插入到页面中
        this.oMain.insertBefore(this.section,this.oPage);
        this.skip();
    }
    skip(){
        this.oDiv2.onclick=()=>{
            sessionStorage.setItem('data_id_carl',this.obj.id); 
        }
        this.oDiv5.onclick=()=>{
            sessionStorage.setItem('data_id_carl',this.obj.id); 
        }
    }
}