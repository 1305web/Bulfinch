$.ajax({
    url: "http://192.168.7.221:3000/companylist",
    type: "get",
    dataType: "jsonp",
    success: function(result){
        let aTextid = [];
        let oTxet =  $("div[class='sec_fivesmallbox_content_lx']");
        console.log(oTxet[0])
        for(let i = 0 ; i < 3 ; i++){
            aTextid.push(result.result[i].id);
        };       
        for(let i = 0 ; i < aTextid.length ;i++){
            $.post("http://192.168.7.221:3000/companydetail",{id:aTextid[i]},(resu)=>{
                $("div[class='sec_fivebox_lx']").eq(i).html(resu.title+"<br><br>"+resu.place_date);
            })                  
        };             
    }
})