$(function(){
    let flag = true;
    $('.tab_carl').click(()=>{
        if(flag){
            $('.nav_intro_carl').addClass('introduce_carl').removeClass('introduction_carl');
            $('body').css('overflow','hidden');
            $('.tab_carl>p:nth-child(1)').css('top','15px').css('transform','rotate(135deg)');
            $('.tab_carl>p:nth-child(2)').css('left','-13px').css('opacity','0');
            $('.tab_carl>p:nth-child(3)').css('top','-13px').css('transform','rotate(-135deg)');
        }else{
            $('.nav_intro_carl').removeClass('introduce_carl').addClass('introduction_carl');
            $('body').css('overflow','initial');
            $('.tab_carl>p:nth-child(1)').css('top','0px').css('transform','rotate(0deg)');
            $('.tab_carl>p:nth-child(2)').css('left','0px').css('opacity','1');
            $('.tab_carl>p:nth-child(3)').css('top','0px').css('transform','rotate(0deg)');
        }
        flag=!flag;
    })

})