class Click{
    constructor(){
        this.oBox = document.querySelector(".nav_rail_lx")
        this.oP = document.getElementsByClassName("nav_linkbox_lx")[0];
        this.aLine = this.oBox.children;
        this.oBox.addEventListener("click",this.open());
        this.flag = true;
    }
    open(){     
        return ()=>{         
            if(this.flag){
                this.oP.style.display = "block";
                let add = 100;
                this.aLine[0].style.top  = "10px";
                this.aLine[2].style.bottom  = "16px";   
                this.aLine[1].style.transform = "translate("+(-add)+"px)";
                this.aLine[1].style.opacity = "0";
                this.aLine[0].style.transform = "rotate(-225deg)";
                this.aLine[2].style.transform = "rotate(225deg)";       
            }else{
                this.oP.style.display = "none";
                this.aLine[0].style.top  = "0px";
                this.aLine[2].style.bottom  = "0px";   
                this.aLine[1].style.transform = "translate(0px)";
                this.aLine[1].style.opacity = "1";
                this.aLine[0].style.transform = "rotate(0deg)";
                this.aLine[2].style.transform = "rotate(0deg)";     
            }
            this.flag = !this.flag;
            console.log(this.flag);         
        }       
    }
}


var click = new Click()


