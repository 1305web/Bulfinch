$(function(){
                 
    var type_Stars=document.getElementById('type_Stars');
    var city_Stars=document.getElementById('city_Stars');
    var price_Stars=document.getElementById('price_Stars');
    
    type_Stars.onchange=lookup;
    city_Stars.onchange=lookup;
    price_Stars.onchange=lookup;                
    
    function lookup(){
        if(type_Stars.value=='剑桥' && city_Stars.value=='类型' && price_Stars.value=='方形镜头' || type_Stars.value=='剑桥' && city_Stars.value=='办公室' && price_Stars.value=='方形镜头'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli1_Stars').css('display','block').css('opacity','1')
                $('#fourthElementsli9_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='剑桥' && city_Stars.value=='实验室' && price_Stars.value=='方形镜头' || type_Stars.value=='剑桥' && city_Stars.value=='R & D' && price_Stars.value=='方形镜头' || type_Stars.value=='剑桥' && city_Stars.value=='类型' && price_Stars.value=='200,000-300,000' || type_Stars.value=='剑桥' && city_Stars.value=='实验室' && price_Stars.value=='200,000-300,000' || type_Stars.value=='剑桥' && city_Stars.value=='办公室' && price_Stars.value=='200,000-300,000' || type_Stars.value=='剑桥' && city_Stars.value=='R & D' && price_Stars.value=='200,000-300,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli1_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='剑桥' && city_Stars.value=='零售' && price_Stars.value=='方形镜头' || type_Stars.value=='剑桥' && city_Stars.value=='类型' && price_Stars.value=='0-50,000' || type_Stars.value=='剑桥' && city_Stars.value=='办公室' && price_Stars.value=='0-50,000' || type_Stars.value=='剑桥' && city_Stars.value=='零售' && price_Stars.value=='0-50,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli9_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='欣厄姆' && city_Stars.value=='类型' && price_Stars.value=='方形镜头' || type_Stars.value=='欣厄姆' && city_Stars.value=='办公室' && price_Stars.value=='方形镜头' || type_Stars.value=='欣厄姆' && city_Stars.value=='办公室' && price_Stars.value=='0-50,000' || type_Stars.value=='欣厄姆' && city_Stars.value=='办公室' && price_Stars.value=='50,000-100,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli6_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='利特尔顿' && city_Stars.value=='类型' && price_Stars.value=='方形镜头' || type_Stars.value=='利特尔顿' && city_Stars.value=='办公室' && price_Stars.value=='方形镜头' || type_Stars.value=='利特尔顿' && city_Stars.value=='R & D' && price_Stars.value=='方形镜头' || type_Stars.value=='利特尔顿' && city_Stars.value=='办公室' && price_Stars.value=='50,000-100,000' || type_Stars.value=='利特尔顿' && city_Stars.value=='R & D' && price_Stars.value=='50,000-100,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli5_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='李约瑟' && city_Stars.value=='类型' && price_Stars.value=='方形镜头' || type_Stars.value=='李约瑟' && city_Stars.value=='办公室' && price_Stars.value=='方形镜头'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli2_Stars').css('display','block').css('opacity','1')
                $('#fourthElementsli4_Stars').css('display','block').css('opacity','1')
                $('#fourthElementsli7_Stars').css('display','block').css('opacity','1')
                $('#fourthElementsli8_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='李约瑟' && city_Stars.value=='办公室' && price_Stars.value=='0-50,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli2_Stars').css('display','block').css('opacity','1')
                $('#fourthElementsli4_Stars').css('display','block').css('opacity','1')
                $('#fourthElementsli7_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='李约瑟' && city_Stars.value=='办公室' && price_Stars.value=='50,000-100,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli8_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='李约瑟' && city_Stars.value=='办公室' && price_Stars.value=='100,000-200,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli4_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='李约瑟' && city_Stars.value=='办公室' && price_Stars.value=='200,000-300,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli2_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='李约瑟' && city_Stars.value=='类型' && price_Stars.value=='方形镜头' || type_Stars.value=='李约瑟' && city_Stars.value=='医疗办公室' && price_Stars.value=='0-50,000' || type_Stars.value=='李约瑟' && city_Stars.value=='零售' && price_Stars.value=='方形镜头' || type_Stars.value=='李约瑟' && city_Stars.value=='零售' && price_Stars.value=='0-50,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli7_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else if(type_Stars.value=='沃尔瑟姆' && city_Stars.value=='类型' && price_Stars.value=='方形镜头' || type_Stars.value=='沃尔瑟姆' && city_Stars.value=='实验室' && price_Stars.value=='方形镜头' || type_Stars.value=='沃尔瑟姆' && city_Stars.value=='办公室' && price_Stars.value=='方形镜头' || type_Stars.value=='沃尔瑟姆' && city_Stars.value=='实验室' && price_Stars.value=='50,000-100,000' || type_Stars.value=='沃尔瑟姆' && city_Stars.value=='办公室' && price_Stars.value=='50,000-100,000'){
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
                $('#fourthElementsli3_Stars').css('display','block').css('opacity','1')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }else{
            setTimeout(function(){
                $('.fourthElements_Stars ul li').css('display','none')
            },500)
            $('.fourthElements_Stars ul li').css('opacity','0.5')
        }
    }
})

