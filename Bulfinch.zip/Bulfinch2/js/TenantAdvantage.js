$(function(){

    for(let i=1;i<35;i++){        
        let tenantAdvantageDiv_Stars=$("<div class='tenantAdvantageDiv_Stars'><img src='../img/TenantAdvantageImg/ExclusiveDiscount"+i+".png'></div>")    
        $('.seventhElements_Stars').append(tenantAdvantageDiv_Stars)
    }
                
})

